$(".logo-slider").slick({
    slidesToShow: 4,
    slidesToscroll: 1,
    dots: true,
    arrows: true,
    autoplay: true,
    autoplayspeed: 1000,
    infinite: true
});

$(".num").counterUp({
    delay:20,
    time: 1000,
});